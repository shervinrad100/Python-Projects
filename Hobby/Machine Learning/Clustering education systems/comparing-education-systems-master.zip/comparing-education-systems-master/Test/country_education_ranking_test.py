import pandas as pd
import pycountry
import numpy as np
import umap.umap_ as umap
from country_list import countries_for_language
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler


def create_raw_data(filepath, name, col):
    ''' Load excel file into a clean dataframe '''
    df_raw = pd.read_excel(filepath, skiprows=3)
    df_raw.drop(df_raw.iloc[:,2:44].columns, axis=1, inplace=True)
    df_raw.drop(df_raw.iloc[:,-1:].columns,axis=1, inplace=True)
    name = pd.melt(df_raw, id_vars=['Country Name', 'Country Code'], value_vars=df_raw.iloc[:,2:].columns, var_name='year', value_name=col)
    name.sort_values(by=['Country Name', 'year'], inplace=True)
    name.reset_index(inplace=True)
    name.drop(['index'], axis=1, inplace=True)
    return name

def get_df_name(df):
    df = create_demo_2_lists()
    name =[x for x in globals() if globals()[x] is df][0]
    return name

def get_raw_data():
    ''' load dataframes for each metric relating to education,
    then merges these into a df_final '''
    gdp = create_raw_data(f'../../demographic_data/GDP by country.xls', 'gdp', 'gdp')
    gdp_per_capita = create_raw_data(f'../../demographic_data/GDP_per_capita.xls', 'gdp_per_capita', 'gdp_per_capita')
    govt_exp_ter_edu = create_raw_data(f'../../demographic_data/Govt Exp on Education.xls', 'exp_on_education', 'govt_exp_ter_edu')
    literacy_rate = create_raw_data(f'../../demographic_data/Literacy Rate.xls', 'literacy_rate', 'literacy_rate')
    govt_exp_total = create_raw_data(f'../../demographic_data/Total Govt Exp on Education.xls', 'total_govt_exp', 'govt_exp_total')
    avg_class_size = create_raw_data(f'../../demographic_data/Average Class Size.xls', 'avg_class_size', 'avg_class_size')
    enrollment_rate = create_raw_data(f'../../demographic_data/Enrollment.xls', 'enrollment_rate', 'enrollment_rate')
    govt_exp_per_student = create_raw_data(f'../../demographic_data/gov_spend_per_student2.xls', 'govt_exp_student', 'govt_exp_per_student')

    # Loading csv files into separate DataFrames
    tert_grad_rate = pd.read_csv(f'../../demographic_data/tert_grad_rate.csv')
    tert_grad_rate.sort_values(['LOCATION', 'TIME'], inplace=True)
    tert_grad_rate.reset_index(inplace=True)
    tert_grad_rate.drop(['index'], axis=1, inplace=True)
    tert_grad_rate = tert_grad_rate[['LOCATION', 'TIME', 'Value']]
    tert_grad_rate = tert_grad_rate.groupby(by=['LOCATION', 'TIME']).mean()

    sec_grad_rate = pd.read_csv(f'../../demographic_data/sec_grad_rate.csv')
    sec_grad_rate.sort_values(['LOCATION', 'TIME'], inplace=True)
    sec_grad_rate.reset_index(inplace=True)
    sec_grad_rate.drop(['index'], axis=1, inplace=True)
    sec_grad_rate = sec_grad_rate[['LOCATION', 'TIME', 'Value']]
    sec_grad_rate = sec_grad_rate.groupby(by=['LOCATION', 'TIME']).mean()

    int_mobility = pd.read_csv(f'../../demographic_data/int_mobility.csv')
    int_mobility = int_mobility[['LOCATION', 'TIME', 'Value']]

    raw_demographics = [gdp, gdp_per_capita, govt_exp_ter_edu, literacy_rate, govt_exp_total, avg_class_size, enrollment_rate, govt_exp_per_student]
    raw_demographics_2 = [tert_grad_rate, sec_grad_rate, int_mobility]

    cols_to_use = gdp_per_capita.columns.difference(gdp.columns)
    df_final = pd.merge(gdp, gdp_per_capita[cols_to_use], left_index=True, right_index=True, how='outer')

    for i in range(len(raw_demographics)):
        cols_to_use = raw_demographics[i].columns.difference(df_final.columns)
        df_final = pd.merge(df_final, raw_demographics[i][cols_to_use], left_index=True, right_index=True, how='outer')

    df_final['year'] = df_final['year'].astype('int')

    for i in range(len(raw_demographics_2)):
        df_final = df_final.merge(raw_demographics_2[i], left_on=['Country Code', 'year'], right_on=['LOCATION', 'TIME'],
                                  how='outer')
        if i == 0:
            df_final.rename(columns={'Value': 'tert_grad_rate'}, inplace=True)
        elif i == 1:
            df_final.rename(columns={'Value': 'sec_grad_rate'}, inplace=True)
        else:
            df_final.rename(columns={'Value': 'int_mobility'}, inplace=True)

    df_final.drop(columns=['LOCATION', 'TIME'], axis=1, inplace=True)
    df_final.rename(columns={'Country Name': 'country', 'Country Code': 'country_code'}, inplace=True)
    df_final = df_final[['country',
                         'country_code',
                         'year',
                         'gdp',
                         'gdp_per_capita',
                         'govt_exp_total',
                         'govt_exp_ter_edu',
                         'govt_exp_per_student',
                         'avg_class_size',
                         'literacy_rate',
                         'sec_grad_rate',
                         'tert_grad_rate',
                         'enrollment_rate',
                         'int_mobility'
                         ]]
    df_final.dropna(subset=['country', 'country_code'], inplace=True)
    # Result is a tidy table with raw data for each country
    return df_final

def create_final_output():
    '''Uses UMAP to reduce number of dimensions.
    KMeans Clustering used to cluster groups of countries together based on education metrics.
    Countries with nulls (not included in KMeans) are assigned to clusters.
    Each cluster is ranked, for output'''
    df_final = get_raw_data()
    df_avg = df_final.groupby(by=['country', 'country_code']).mean()
    # Drop the redundant columns
    df_avg.drop(columns=['year', 'sec_grad_rate', 'tert_grad_rate', 'int_mobility', 'literacy_rate'], inplace=True)
    df_avg = df_avg.reset_index()

    # Removing regions/groups of countries (e.g. Caribbean) to leave only countries
    countries = list(pycountry.countries)
    codes = [item.alpha_3 for item in countries]
    codes.append('WLD')
    for code in df_avg['country_code']:
        if code not in codes:
            df_avg.drop(df_avg[df_avg['country_code'] == code].index, inplace=True)
    df_avg = df_avg.reset_index()
    df_avg.drop(columns=['index'], axis=1, inplace=True)

    df_avg.set_index('country', inplace=True)

    # UMAP used to reduce the number of dimensions to allow for easier use of KMeans Clustering
    reducer = umap.UMAP()
    country_data = df_avg[
        ['gdp_per_capita', 'govt_exp_total', 'govt_exp_ter_edu', 'govt_exp_per_student', 'avg_class_size',
         'enrollment_rate']].dropna().values
    embedding = reducer.fit_transform(country_data)

    z = embedding
    StandardScaler().fit_transform(z)
    model = KMeans(n_clusters=6, init='k-means++')
    model.fit(z)
    labels = model.predict(z)

    df_clusters = df_avg.dropna()
    df_clusters['cluster_UMAPED'] = labels

    # Removing countries from df_avg that have more than 3 null values
    ignore_list = []
    for country in df_avg.index.values.tolist():
        try:
            if df_avg.loc[country, ['gdp_per_capita', 'govt_exp_total', 'govt_exp_ter_edu', 'govt_exp_per_student',
                                    'avg_class_size', 'enrollment_rate']].isnull().value_counts()[False] <= 3:
                ignore_list.append(country)
        except:
            if df_avg.loc[country, ['gdp_per_capita', 'govt_exp_total', 'govt_exp_ter_edu', 'govt_exp_per_student',
                                    'avg_class_size', 'enrollment_rate']].isnull().value_counts()[True] > 3:
                ignore_list.append(country)
    df_avg = df_avg[~df_avg.index.isin(ignore_list)]

    df_avg = df_avg.join(df_clusters.loc[:, 'cluster_UMAPED'], how='left')

    df_cluster_centroid = df_clusters.groupby(by='cluster_UMAPED').mean()

    # Assigning cluster to countries not included in KMeans
    def assign_cluster(country):
        dist = {cluster: {col: None for col in df_cluster_centroid.columns} for cluster in
                df_cluster_centroid.index.to_list()}

        for cluster in df_cluster_centroid.index.to_list():
            for col in df_cluster_centroid.columns:
                if df_avg.loc[country].isnull()[col]:
                    pass
                else:
                    dist[cluster][col] = (df_avg.loc[country, col] - df_cluster_centroid.loc[cluster, col]) ** 2

            cluster_vals = list(dist[cluster].values())
            while None in cluster_vals:
                cluster_vals.remove(None)
            dist[cluster]['dist_to_cluster'] = (sum(cluster_vals)) ** 0.5

        temp = dist[0]['dist_to_cluster']
        for cluster in dist.keys():
            if dist[cluster]['dist_to_cluster'] >= temp:
                pass
            else:
                temp = dist[cluster]['dist_to_cluster']

        for cluster in dist.keys():
            if list(dist.values())[cluster]['dist_to_cluster'] == temp:
                df_avg.loc[country, 'cluster_UMAPED'] = cluster
                return f'{country} #assigned# to cluster {cluster}'
            else:
                outpt = f'{country} NOT ASSIGNED  {cluster}'
        return outpt

    for country in df_avg.index.to_list():
        for col in df_avg.columns[:-1]:
            if df_avg.loc[country].isnull()[col]:
                assign_cluster(country)

    # Converted all columns so that 'more is better'
    df_cluster_centroid['avg_class_size'] = 1 / (df_cluster_centroid['avg_class_size'])

    def euclidean_dist(dataframe):
        lst = []
        for i in range(len(dataframe)):
            lst.append((sum(list(map(lambda x: x ** 2, df_cluster_centroid.loc[i])))) ** 0.5)
        dataframe['euclidean_dist'] = lst
        return dataframe

    df_rank_clusters = euclidean_dist(df_cluster_centroid)

    # Ranked clusters based on Euclidean distance from the origin
    df_rank_clusters['rank'] = df_rank_clusters['euclidean_dist'].rank(ascending=False)

    for country in df_avg.index.to_list():
        cluster = df_avg.loc[country, 'cluster_UMAPED']
        df_avg.loc[country, 'rank'] = df_rank_clusters.loc[cluster, 'rank']

    # Tidying up the final output
    df_output = df_avg[['country_code',
                        'rank',
                        'gdp_per_capita',
                        'govt_exp_total',
                        'govt_exp_ter_edu',
                        'govt_exp_per_student',
                        'avg_class_size',
                        'enrollment_rate'
                        ]]

    df_output.to_csv(f'df_output.csv')
    return df_output
