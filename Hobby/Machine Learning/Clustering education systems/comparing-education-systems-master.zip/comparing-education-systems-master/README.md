# **Comparing Education Systems**

_Uses Python3.7_  <br>
_Uses Chrome for all webdrivers_

### **Aim**:
To allow a hiring manager from JP Morgan to easily compare students from different backgrounds based on education systems around the world. 

### **Method**:
Split the task in two: 
1) Comparing university rankings across the world
    * Collecting various league tables and containing rankings and other data for the top 1527 universities
    * Obtain geographical information for each university
    <br/>
2) Comparing education systems for each country 
    * Obtained metrics relating to quality of educational system for every country
    * Cleansed the data, loaded into DataFrame
    * Performed a UMAP (dimension reduction algorithm) to allow for accurate grouping later
    * Performed a KMeans cluster on the DataFrame to sort countries into 6 groups 
    * Countries excluded from KMeans then allocated to a group
    * Each group is ranked based on the quality of education system (using Euclidean distance from origin) <br>

### **Outputs**
1) University comparisons:
    * A [csv](Scripts/Uni_Rankings/final_uni_table.csv) file `Scripts/Uni_Rankings/final_uni_table.csv`containing rankings and metrics for each university: 
      - world ranking 
      - city
      - country
      - country population
      - students per staff
      - female to male ratio
      - world computer science ranking 
      - world business and economics ranking
      - national ranking
      - world employability ranking
    * Interactive Tableau tool used to facilitate university and country comparison on a variety of metrics
    <br/>
2) Country comparisons: 
    * DataFrame with country name, ranked cluster and six metrics relating to education systems
    * DataFrame exported to a [csv](Scripts/Country_Education_Systems/df_output.csv) file `Scripts/Country_Education_Systems/df_output.csv` to be used in visualisations <br>

_All research has been combined and exported to Tableau to provide an interactive dashboard for the JP Morgan hiring manager to use._ <br>

### **Instructions**

* To obtain the csv of world university metrics, run `python Script/Uni_Rankings/uni_ranking_table.py` from the comparing-education-systems directory.  The csv will then be readable from `final_uni_table.csv`.
* To obtain the csv of global education metrics, run `python Script/Country_Education_Systems/run_country_education_ranking.py` from the comparing-education-systems directory.  The csv will then be readable from `df_output.csv`.  

### **Sources**
* [The Times HE](https://www.timeshighereducation.com/)
* [World Bank data](https://data.worldbank.org/)
* [OECD data](https://data.oecd.org/)
* Data files can be found [here](demographic_data)
    * For [sec_grad_rate](demographic_data/sec_grad_rate.csv), [tert_grad_rate](demographic_data/tert_grad_rate.csv) and [int_mobility](demographic_data/int_mobility.csv) files, query OECD data using 'Indicator' column
    * For all other csv files, query World Bank data website using 'Indicator Name' column