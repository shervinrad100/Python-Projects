import get_all_rankings

df = get_all_rankings.main_script()

df.to_csv('final_uni_table.csv')
