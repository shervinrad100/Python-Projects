import pandas as pd
import requests
import selenium
import time
from bs4 import BeautifulSoup
from selenium import webdriver


def get_employability_rankings():
    ''' this function scrapes the employability ranking table
    for each university and loads in into a dataframe/csv '''

    driver = webdriver.Chrome()
    driver.get(r'https://www.timeshighereducation.com/student/best-universities/best-universities-graduate-jobs-global-university-employability-ranking')
    time.sleep(10)

    click_soup = BeautifulSoup(driver.page_source, 'html.parser')
    click_soup = click_soup.find('select', {'name':'datatables-684412_length'})

    # click on the 100 in the dropdown option, to show 100 rows at a time
    click_el = driver.find_element_by_id('datatables-684412_length')
    for option in click_el.find_elements_by_tag_name('option'):
        if option.text == '100':
            option.click()
            break

    # scrapes the table
    soup = BeautifulSoup(driver.page_source, 'html.parser')
    soup = soup.find('table', {'id':'datatables-684412'})
    table_rows = soup.find_all('tr')
    list_of_vals = []
    for item in table_rows[1:]:
        entry = item.find_all('td')
        gentry = [x.text for x in entry]
        list_of_vals.append(gentry)

    cols = ['Employability Rank 2019', 'Institution', 'Country', 'Employability Rank 2018', 'World Rank']
    df_empl_rank = pd.DataFrame(list_of_vals, columns=cols)

    # click 'Next' button to go to the next page on the website, to get the next 100 rows and scrape them
    next_soup = BeautifulSoup(driver.page_source, 'html.parser')
    next_soup = next_soup.find('li', {'class': 'paginate_button next'})

    for i in range(2):
        driver.find_element_by_link_text('Next').click()
        soup = BeautifulSoup(driver.page_source, 'html.parser')
        soup = soup.find('table', {'id': 'datatables-684412'})
        table_rows = soup.find_all('tr')
        list_of_vals = []
        for item in table_rows[1:]:
            entry = item.find_all('td')
            gentry = [x.text for x in entry]
            list_of_vals.append(gentry)
        df_next = pd.DataFrame(list_of_vals, columns=cols)
        df_empl_rank = df_empl_rank.append(df_next, ignore_index=True)

    df_empl_rank.to_csv(f'df_empl_rank.csv')
    return df_empl_rank

get_employability_rankings()
