# -*- coding: utf-8 -*-
"""
Created on Tue Oct 20 16:44:25 2020

@author: benny
"""


from selenium import webdriver
from selenium.webdriver.chrome.options import Options
import time
import requests
import json
from bs4 import BeautifulSoup as bs
import datetime as dt
import pandas as pd

def get_populations():

    url = r'https://en.wikipedia.org/wiki/List_of_countries_by_population_(United_Nations)'
    opts = Options()
    opts.add_argument("--headless")

    with webdriver.Chrome(options=opts) as driver:
        driver.get(url)
        time.sleep(2)
        soup = bs(driver.page_source, 'html.parser')

    table = soup.find('table', {'class':'nowrap sortable mw-datatable wikitable jquery-tablesorter'})
    table = table.find('tbody')

    tag = 'tr'
    attributes = {'class':'adr'}
    country_deets = table.find_all(tag)

    country_list = []
    population_list = []

    for country in country_deets:
        country = country.find_all('td')[0].text.strip().split('[', maxsplit=1)[0]
        country_list.append(country)

    for population in country_deets:
        population = int(population.find_all('td')[4].text.replace(',', ''))
        population_list.append(population)
        
    country_population = zip(country_list, population_list)
    df = pd.DataFrame(list(country_population), columns = ['country', '2019_population'])
    
    return df

if __name__ == '__main__':
    get_populations()