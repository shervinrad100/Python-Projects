from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.keys import Keys
import requests
from bs4 import BeautifulSoup
import datetime as dt
import time
import pprint
import pandas as pd
import os
import re
import pycountry
import json

def initialise_webscrape(url):
    ''' this initialisation of a webscrape is used repeatedly
        returns soup object'''

    with webdriver.Chrome() as driver:
        driver.get(url)
        time.sleep(5)
        soup = BeautifulSoup(driver.page_source, 'html.parser')

    return soup




def national_rankings():
    ''' this function collects the national rankings and cities for universities in a collection of countries
        returns national ranking dataframe'''

    df_national_ranking = pd.DataFrame(columns=['National Ranking', 'University', 'City', 'Country'])

    #countries = [country.name.lower().replace(' ', '-') for country in list(pycountry.countries)]

    #countries is a list of countries that the times has tables for
    countries = ['australia', 'brazil', 'canada', 'switzerland', 'china', 'cyprus', 'germany', 'denmark', 'egypt', 'spain', 'france',
                 'india', 'ireland', 'italy', 'mexico', 'malaysia', 'netherlands', 'new-zealand', 'pakistan', 'poland', 'sweden', 'united-states', 'uk', 'south-korea']

    driver = webdriver.Chrome()

    # we try two ways of scraping as the location of the table in the html can be in one of two locations
    for country in countries:
        try:
            driver.get(r'https://www.timeshighereducation.com/student/best-universities/best-universities-' + country)
            time.sleep(5)

            try:
                soup = BeautifulSoup(driver.page_source, 'html.parser')
                driver.quit()
                soup = soup.find('tbody')
                table_rows = soup.find_all('tr')
                if country == 'egypt' or country == 'malaysia' or country == 'cyprus':      # Egpyt, Malaysia and Cyprus tables have different columns on the website
                    rankings_list = [entry.find_all('td')[0].text for entry in table_rows]
                else:
                    rankings_list = [entry.find_all('td')[1].text for entry in table_rows]
                university_list = [entry.find_all('td')[2].text for entry in table_rows]
                city_list = [entry.find_all('td')[3].text for entry in table_rows]

            except:
                try:
                    soup = BeautifulSoup(driver.page_source, 'html.parser')
                    soup = soup.find('div', {'class':'table-responsive'})
                    table_rows = soup.find_all('tr')
                    if country == 'egypt' or country == 'malaysia' or country == 'cyprus':
                        rankings_list = [entry.find_all('td')[0].text for entry in table_rows]
                    else:
                        rankings_list = [entry.find_all('td')[1].text for entry in table_rows]
                    university_list = [entry.find_all('td')[2].text for entry in table_rows]
                    city_list = [entry.find_all('td')[3].text for entry in table_rows]
                except:
                    continue

            # we have collected the ranking, uni name and city
            dict_for_table = {'National Ranking': rankings_list[1:], 'University': university_list[1:], 'City' : city_list[1:]}
            table = pd.DataFrame(dict_for_table)
            title = country.title().replace('-', ' ')
            if country == 'uk':
                table['Country'] = 'United Kingdom'
            else:
                table['Country'] = title
            df_national_ranking = df_national_ranking.append(table)

        except:
            continue

    # Hong Kong has a table with different columns
    driver.get(r'https://www.timeshighereducation.com/student/best-universities/best-universities-hong-kong')
    time.sleep(5)

    soup = BeautifulSoup(driver.page_source, 'html.parser')
    driver.quit()
    soup = soup.find('tbody')
    table_rows = soup.find_all('tr')
    rankings_list = [entry.find_all('td')[1].text for entry in table_rows]
    university_list = [entry.find_all('td')[2].text for entry in table_rows]

    dict_for_table = {'National Ranking': rankings_list[1:], 'University': university_list[1:]}
    table = pd.DataFrame(dict_for_table)
    table['City'] = 'Hong Kong'
    table['Country'] = 'Hong Kong'

    df_national_ranking = df_national_ranking.append(table)

    return df_national_ranking



def world_rankings():
    ''' this function collects the world university rankings
        returns world ranking dataframe'''

    soup = initialise_webscrape(r'https://www.timeshighereducation.com/world-university-rankings/2021/world-ranking#!/page/0/length/-1/sort_by/rank/sort_order/asc/cols/stats')
    soup = soup.find('table', {'id':'datatable-1'})
    soup = soup.find('tbody')
    table_rows = soup.find_all('tr')
    rankings_list = [entry.find_all('td')[0].text for entry in table_rows]
    # uni_names_list contains the uni and country. It is cleaned below
    uni_names_list = [entry.find_all('td')[1].text for entry in table_rows]
    students_per_staff = [float(entry.find_all('td')[3].text) for entry in table_rows]
    female_to_male = [entry.find_all('td')[5].text for entry in table_rows]

    uni_names_list = [name.replace('Enquire', '').replace('Explore', '') for name in uni_names_list]

    table = []
    for row in uni_names_list:
        if row == 'Saint-Petersburg Mining University Russian Federation':
            table.append(['Saint-Petersburg Mining University', 'Russian Federation'])
            continue
        if row == 'Miguel Hernández University of Elche Spain':
            table.append(['Miguel Hernández University of Elche', 'Spain'])
            continue
        if row == 'Federal University of Health Sciences of Porto Alegre (UFCSPA) Brazil':
            table.append(['Federal University of Health Sciences of Porto Alegre (UFCSPA)','Brazil'])
            continue
        if row == 'Kazan National Research Technical University Russian Federation':
            table.append(['Kazan National Research Technical University', 'Russian Federation'])
            continue
        # we now split the uni_names_list into the uni and the country
        count = 0
        matches = re.finditer(r'[a-z][A-Z]|[/)][A-Z]|[A-Z][A-Z][a-z]|[0-9][A-Z]|[ä,é,ź,í,ń,á][A-Z]', row)
        for match in matches:
            count += 1
        if count > 0:
            uni = row[:row.index(match[0])+1]
            country = row[row.index(match[0])+1:]
            table.append([uni,country])

    university = [row[0] for row in table]
    country = [row[1] for row in table]

    table = {'World ranking': rankings_list, 'University': university, 'Country' : country,
         'Students per Staff': students_per_staff, 'Female to Male': female_to_male}

    df_world_rankings = pd.DataFrame(table)
    return df_world_rankings




def comp_sci_rankings():
    ''' this function collects the global computer science rankings for the top computer science universities
        returns comp sci ranking dataframe'''

    soup = initialise_webscrape(r'https://www.timeshighereducation.com/world-university-rankings/2020/subject-ranking/computer-science#!/page/0/length/-1/sort_by/rank/sort_order/asc/cols/stats')
    soup = soup.find('table', {'id':'datatable-1'})
    soup = soup.find('tbody')
    table_rows = soup.find_all('tr')
    rankings_list = [entry.find_all('td')[0].text for entry in table_rows]
    uni_names_list = [entry.find_all('td')[1].text for entry in table_rows]

    uni_names_list = [name.replace('Enquire', '').replace('Explore', '') for name in uni_names_list]

    table = []
    for row in uni_names_list:
        if row == 'Saint-Petersburg Mining University Russian Federation':
            table.append(['Saint-Petersburg Mining University', 'Russian Federation'])
            continue
        if row == 'Miguel Hernández University of Elche Spain':
            table.append(['Miguel Hernández University of Elche', 'Spain'])
            continue
        if row == 'Federal University of Health Sciences of Porto Alegre (UFCSPA) Brazil':
            table.append(['Federal University of Health Sciences of Porto Alegre (UFCSPA)','Brazil'])
            continue
        if row == 'Kazan National Research Technical University Russian Federation':
            table.append(['Kazan National Research Technical University', 'Russian Federation'])
            continue
        count = 0
        matches = re.finditer(r'[a-z][A-Z]|[/)][A-Z]|[A-Z][A-Z][a-z]|[0-9][A-Z]|[ä,é,ź,í,ń,á][A-Z]', row)
        for match in matches:
            count += 1
        if count > 0:
            uni = row[:row.index(match[0])+1]
            country = row[row.index(match[0])+1:]
            table.append([uni,country])

    university = [item[0] for item in table]
    country = [item[1] for item in table]

    table = {'World Computer Science Ranking': rankings_list, 'University': university, 'Country' : country}

    return pd.DataFrame(table)



def business_economics_rankings():
    '''this function collects the global business rankings for the top business rankings
        returns business ranking dataframe'''

    soup = initialise_webscrape(r'https://www.timeshighereducation.com/world-university-rankings/2020/subject-ranking/business-and-economics#!/page/0/length/-1/sort_by/rank/sort_order/asc/cols/stats')

    soup = soup.find('table', {'id':'datatable-1'})
    soup = soup.find('tbody')
    table_rows = soup.find_all('tr')
    rankings_list = [entry.find_all('td')[0].text for entry in table_rows]
    uni_names_list = [entry.find_all('td')[1].text for entry in table_rows]

    uni_names_list = [name.replace('Enquire', '').replace('Explore', '') for name in uni_names_list]

    table = []
    for row in uni_names_list:
        if row == 'Saint-Petersburg Mining University Russian Federation':
            table.append(['Saint-Petersburg Mining University', 'Russian Federation'])
            continue
        if row == 'Miguel Hernández University of Elche Spain':
            table.append(['Miguel Hernández University of Elche', 'Spain'])
            continue
        if row == 'Federal University of Health Sciences of Porto Alegre (UFCSPA) Brazil':
            table.append(['Federal University of Health Sciences of Porto Alegre (UFCSPA)','Brazil'])
            continue
        if row == 'Kazan National Research Technical University Russian Federation':
            table.append(['Kazan National Research Technical University', 'Russian Federation'])
            continue
        count = 0
        matches = re.finditer(r'[a-z][A-Z]|[/)][A-Z]|[A-Z][A-Z][a-z]|[0-9][A-Z]|[ä,é,ź,í,ń,á][A-Z]', row)
        for match in matches:
            count += 1
        if count > 0:
            uni = row[:row.index(match[0])+1]
            country = row[row.index(match[0])+1:]
            table.append([uni,country])

    university = [item[0] for item in table]
    country = [item[1] for item in table]

    table = {'World Business and Economics Ranking': rankings_list, 'University': university, 'Country' : country}

    return pd.DataFrame(table)



def get_wiki_city(uni):
    ''' this function gets the city of any university from Wikipedia.  The input must looks like, for instance, University_of_Oxford
        returns a city for the university given'''

    url = r'https://en.wikipedia.org/wiki/' + uni
    opts = Options()
    opts.add_argument("--headless")

    with webdriver.Chrome(options=opts) as driver:
        driver.get(url)
        time.sleep(0.5)
        soup = BeautifulSoup(driver.page_source, 'html.parser')

    table = soup.find('table', {'class':'infobox vcard'})
    table = table.find('tbody')

    tag = 'td'
    attributes = {'class':'adr'}
    uni_city = table.find_all(tag, attributes)

    for location in uni_city:
        location = location.text
        location = location.split(',')[0]

    return location



def populate_cities(df):
    ''' this function fully populates the cities column by using get_wiki_city() and cleaning incorrect values
        takes in a dataframe and returns it with the cities column populated'''

    #four lists of captured values from the scrape which are not correct

    known_unis = ['HSE University', 'Peter the Great St Petersburg Polytechnic University',
                       'University of Occupational and Environmental Health, Japan',
                       'China Medical University, Taiwan',
                       'University of Desarrollo',
                       'Mizzou - University of Missouri',
                       'Pontifical Javeriana University',
                       'Saint-Petersburg Mining University',
                       'Universidad Autónoma de Chile',
                       'Ferhat Abbas Sétif University 1',
                       'The University of the West Indies',
                       'The University of Aizu',
                       'ISCTE-University Institute of Lisbon',
                       'Kansai Medical University',
                       'University of Kurdistan',
                       'National University of Science and Technology (MISiS)',
                       'Nippon Medical School', 'Yasouj University',
                       'University of the Andes, Colombia', 'Asia University, Taiwan',
                       'Hyogo College of Medicine',
                       'Iuliu Haţieganu University of Medicine and Pharmacy Cluj-Napoca',
                       'Kharkiv National University of Radio Electronics',
                       'King Mongkut’s University of Technology Thonburi', 'Kyoto Prefectural University of Medicine',
                       'University of Oran 1', 'Tokyo Medical University', 'Vietnam National University (Ho Chi Minh City)', 'Volgograd State Technical University',
                       'University of the Andes, Chile', 'University of the Andes, Venezuela', 'Belgorod State National Research University',
                       'Bezmiâlem Vakif University', 'Blida 1 University', 'University of Chemistry and Technology, Prague',
                       'University of Constantine 1', 'Dunarea de Jos University of Galati', 'University of Economics, Prague',
                       'The University of Electro-Communications', 'George Emil Palade University of Medicine, Pharmacy, Science, and Technology of Targu Mures', 'Ibn Tofaïl University',
                       'Immanuel Kant Baltic Federal University', 'Jan Evangelista Purkyně University', 'Kanazawa Medical University',
                       'Kazan National Research Technical University', 'University of Manouba', 'University of Marrakech Cadi Ayyad',
                       "M'Hamed Bougara University of Boumerdès", 'MIREA - Russian Technological University',
                       'Mohammed V University of Rabat', 'Nara Medical University', 'National Research Saratov State University',
                       'National Technical University of Ukraine – Igor Sikorsky Kyiv Polytechnic Institute', 'Osaka Institute of Technology',
                       'Saitama Medical University', 'Samara University', 'University of Santiago, Chile (USACH)', 'University of Science and Technology of Oran Mohamed-Boudiaf',
                       'Sechenov University', 'Shibaura Institute of Technology Tokyo', 'Shiga University of Medical Science', 'Showa University',
                       'Simón Bolívar University', 'St Marianna University School of Medicine', 'St Petersburg Electrotechnical University (LETI)',
                       'University of Technology, Iraq', 'Tokyo University of Agriculture', 'Vietnam National University (Ho Chi Minh City)',
                       'VSB - Technical University of Ostrava']

    known_solns = ['Moscow', 'Saint Petersburg', 'Kitakyushu', 'Shenyang', 'Concepción', 'Columbia', 'Bogotá',
                       'Saint Petersburg', 'Providencia', 'Sétif', 'Mona', 'Aizuwakamatsu', 'Lisbon', 'Hirakata',
                       'Erbil', 'Moscow', 'Tokyo', 'Yasouj', 'Bogotá',
                       'Taichung City', 'Nishinomiya', 'Cluj-Napoca', 'Kharkiv', 'Bangkok', 'Kyoto', 'Oran',
                       'Tokyo', 'Hanoi', 'Volgograd', 'Santiago', 'Mérida', 'Belgorod', 'Istanbul', 'Blida', 'Prague',
                       'Constantine', 'Galați', 'Prague', 'Chofu', 'Târgu Mureş', 'Kenitra', 'Kaliningrad', 'Ústí nad Labem',
                       'Uchinada', 'Kazan', 'Manouba', 'Marrakesh', 'Boumerdès', 'Moscow', 'Rabat', 'Kashihara', 'Saratov',
                       'Kiev', 'Osaka', 'Saitama', 'Samara', 'Santiago', 'Oran', 'Moscow', 'Tokyo', 'Otsu', 'Shinagawa City',
                       'Caracas', 'Kawasaki', 'Saint Petersburg', 'Baghdad', 'Setagaya City', 'Hanoi', 'Ostrava']

    final_city_changes = ['Taipei', 'Hsinchu', 'Moscow', 'Douliu', 'Yamagata', 'Tsu', 'Kazan', 'Cluj-Napoca', 'Almaty',
                          'Manila', 'Brașov', 'Moscow', 'Chiang Rai', 'Tabriz', 'Tomsk', 'Timișoara', 'Tokyo', 'Tokyo', 'Buenos Aires',
                          'Saint Petersburg', 'Dubai', 'Almaty', 'Irbid', 'Zhuhai', 'Santiago', 'Cotai', 'Valdivia', 'Lima',
                          'Lima', 'Basra', 'Biskra', 'Tokyo', 'Chía', 'Changhua City', 'Chiayi', 'Bogotá', 'Taipei', 'Manila',
                          'Durban', 'Debrecen', 'Tabriz', 'Taoyuan City', 'Kaohsiung', 'Hanoi', 'Melaka', 'Hiroshima',
                          'Hsinchu', 'Hualien', 'Ife', 'Sumedang', 'Jerusalem', 'Bandung', 'Singapore', 'Kami', 'Kitakyushu',
                          'Kochi', 'Kofu', 'Perm', 'Kagoshima', 'Tokyo', 'Saint Petersburg', 'Moscow', 'Košice', 'Liège',
                          'Ljubljana', 'Vienna', 'Kaohsiung', 'Nagoya', 'Barranquilla', 'Matsue', 'Tokyo', 'Mibu', 'Chiayi',
                          'Chiang Mai', 'Phitsanulok', 'Lesvos', 'Kaohsiung', 'New Taipei City', 'Lagos', 'Moscow', 'Brussels',
                          'Potchefstroom', 'Vila Real', 'Riga', 'Cape Town', 'Krasnoyarsk', 'Bratislava', 'Mona', 'Bangkok',
                          'Kaohsiung', 'San Pedro', 'New Taipei City', 'Istanbul', 'Tokyo', 'Shahrud', 'Taichung', 'Tokyo',
                          'Tokyo', 'Taipei', 'Shizuoka', 'Shizuoka', 'Hualien', 'Yogyakarta', 'Taichung', 'Belgrade', 'Osaka',
                          'Taichung', 'Taipei', 'Taichung', 'Taipei', 'Msida', 'New Taipei City', 'Tehran', 'Tokyo', 'Voronezh',
                          'Accra', 'Bratislava', 'Volos', 'Taichung', 'Taipei', 'Taichung', 'Taichung', 'Yasuj', 'Taoyuan',
                          'Taoyuan', 'Taoyuan', 'Keelung']

    final_uni_to_change = ['National Taipei University of Technology', 'National Chiao Tung University', 'RUDN University',
                           'National Yunlin University of Science and Technology', 'Yamagata University', 'Mie University',
                           'Kazan Federal University', 'Babeş-Bolyai University', 'Satbayev University',
                           'De La Salle University', 'Transilvania University of Brașov', 'Bauman Moscow State Technical University',
                           'Mae Fah Luang University','Azarbaijan Shahid Madani University', 'Tomsk State University',
                           'West University of Timişoara', 'Toho University', 'Sophia University', 'National University of San Martín',
                           'Saint Petersburg State University', 'Zayed University', 'Al-Farabi Kazakh National University',
                           'Jordan University of Science and Technology', 'University of Macau', 'Pontifical Catholic University of Chile',
                           'Macau University of Science and Technology', 'Austral University of Chile',
                           'Universidad Peruana Cayetano Heredia', 'Pontifical Catholic University of Peru',
                           'University of Basrah', 'University of Biskra', 'Ochanomizu University', 'University of La Sabana',
                           'National Changhua University of Education', 'National Chiayi University', 'Del Rosario University',
                           'National Taiwan University of Science and Technology (Taiwan Tech)', 'University of the Philippines',
                           'Durban University of Technology', 'University of Debrecen', 'Tabriz University of Medical Sciences',
                           'Chang Gung University', 'National Sun Yat-Sen University',
                           'Hanoi University of Science and Technology', 'Universiti Teknikal Malaysia Melaka',
                           'Hiroshima University', 'National Tsing Hua University', 'Tzu Chi University',
                           'Obafemi Awolowo University', 'Padjadjaran University', 'Hebrew University of Jerusalem',
                           'Bandung Institute of Technology (ITB)', 'Nanyang Technological University, Singapore',
                           'Kochi University of Technology', 'Kyushu Institute of Technology (Kyutech)', 'Kochi University',
                           'University of Yamanashi', 'Perm National Research Polytechnic University', 'Kagoshima University',
                           'Tokyo University of Marine Science and Technology' ,'ITMO University',
                           'Gubkin Russian State University of Oil and Gas', 'Technical University of Košice',
                           'University of Liège', 'University of Ljubljana', 'University of Vienna', 'I-Shou University',
                           'Meijo University', 'University of the North, Colombia', 'Shimane University',
                           'Tokyo Institute of Technology', 'Dokkyo Medical University', 'National Chung Cheng University',
                           'Chiang Mai University', 'Naresuan University', 'University of the Aegean',
                           'National University of Kaohsiung', 'Fu Jen Catholic University', 'Lagos State University',
                           'Pirogov Russian National Research Medical University', 'Vrije Universiteit Brussel', 'North-West University',
                           'University of Trás-os-Montes and Alto Douro', 'University of Latvia', 'University of the Western Cape',
                           'Siberian Federal University', 'Comenius University in Bratislava', 'The University of the West Indies',
                           'Mahidol University', 'Kaohsiung Medical University', 'University of Costa Rica',
                           'National Taipei University', 'Koç University', 'Tokyo University of Agriculture',
                           'Shahrood University of Technology', 'China Medical University, Taiwan',
                           'Aoyama Gakuin University', 'Showa University', 'National Yang-Ming University',
                           'Shizuoka University', 'University of Shizuoka', 'National Dong Hwa University',
                           'Universitas Gadjah Mada', 'National Chung Hsing University', 'University of Belgrade', 'Osaka University',
                           'Asia University, Taiwan', 'National Taiwan University (NTU)', 'National Chin-Yi University of Technology',
                           'Ming Chuan University', 'University of Malta', 'Tamkang University', 'Kharazmi University',
                           'Rikkyo University', 'Voronezh State University', 'University of Ghana',
                           'Slovak University of Technology in Bratislava', 'University of Thessaly', 'Chaoyang University of Technology',
                           'Taipei Medical University', 'Tunghai University', 'Feng Chia University', 'Yasouj University',
                           'National Central University', 'Chung Yuan Christian University', 'Yuan Ze University',
                           'National Taiwan Ocean University']

    universities = list(df[df['City'].isna()]['University'])
    universities = [name.split(' (')[0].replace('\u200b','') for name in universities]
    universities = [name.split(',')[0].replace(' ','_') for name in universities]

    known = [[known_unis[index], known_solns[index]] for index in range(len(known_unis))]

    city_isnull_universities = list(df[df['City'].isna()]['University'])

    #uses get_wiki_city to find the city for unis not in our known_unis list
    cities = []
    for index, uni in enumerate(universities):
        if city_isnull_universities[index] not in known_unis:
            try:
                city = get_wiki_city(uni)
                cities.append(city)
            except:
                cities.append(None)
        else:
            cities.append(None)

    for index, city in enumerate(cities):
        if city is not None:
            if ' (' in city:
                cities[index] = city.split(' (')[0]
            if '°' in city:
                cities[index] = re.split('[0-9]', city)[0].strip()

    matches = {city_isnull_universities[index] : cities[index] for index in range(len(universities))}

    for index, uni in enumerate(final_uni_to_change):
        matches[uni] = final_city_changes[index]

    #inserts all cities found into the dataframe
    for item in known:
        df.loc[df['University'] == item[0], 'City'] = item[1]

    for uni, city in matches.items():
        if city is not None:
            df.loc[df['University'] == uni, 'City'] = city

    return df



def get_populations():
    ''' this function collects all country populations
        returns a dataframe of country populations'''

    url = r'https://en.wikipedia.org/wiki/List_of_countries_by_population_(United_Nations)'
    opts = Options()
    opts.add_argument("--headless")

    with webdriver.Chrome(options=opts) as driver:
        driver.get(url)
        time.sleep(2)
        soup = BeautifulSoup(driver.page_source, 'html.parser')

    table = soup.find('table', {'class':'nowrap sortable mw-datatable wikitable jquery-tablesorter'})
    table = table.find('tbody')

    tag = 'tr'
    attributes = {'class':'adr'}
    country_deets = table.find_all(tag)

    country_list = []
    population_list = []

    for country in country_deets:
        country = country.find_all('td')[0].text.strip().split('[', maxsplit=1)[0]
        country_list.append(country)

    for population in country_deets:
        population = int(population.find_all('td')[4].text.replace(',', ''))
        population_list.append(population)

    country_population = zip(country_list, population_list)
    df = pd.DataFrame(list(country_population), columns = ['Country', 'Country Population'])

    df.loc[df['Country'] == 'Russia', 'Country'] = 'Russian Federation'
    df.loc[df['Country'] == 'Puerto Rico (United States)', 'Country'] = 'Puerto Rico'
    df.loc[df['Country'] == 'Hong Kong (China)', 'Country'] = 'Hong Kong'
    df.loc[df['Country'] == 'Macau (China)', 'Country'] = 'Macao'
    df.loc[df['Country'] == 'Brunei', 'Country'] = 'Brunei Darussalam'

    return df




def get_employability_rankings():
    ''' this function scrapes the employability ranking table
    for each university and loads in into a dataframe/csv '''
    driver = webdriver.Chrome()
    driver.get(r'https://www.timeshighereducation.com/student/best-universities/best-universities-graduate-jobs-global-university-employability-ranking')
    time.sleep(5)

    click_soup = BeautifulSoup(driver.page_source, 'html.parser')

    click_soup = click_soup.find('select', {'name':'datatables-684412_length'})

    # click on the 100 in the dropdown option, to show 100 rows at a time
    click_el = driver.find_element_by_id('datatables-684412_length')
    for option in click_el.find_elements_by_tag_name('option'):
        if option.text == '100':
            option.click()
            break

    # scrapes the table
    soup = BeautifulSoup(driver.page_source, 'html.parser')
    soup = soup.find('table', {'id':'datatables-684412'})
    table_rows = soup.find_all('tr')
    list_of_vals = []
    for row in table_rows[1:]:
        entry = row.find_all('td')
        row_list = [value.text for value in entry]
        list_of_vals.append(row_list)

    cols = ['World Employability Ranking', 'University', 'Country', 'Employability Rank 2018', 'World Rank']
    df_empl_rank = pd.DataFrame(list_of_vals, columns=cols)

    # click 'Next' button to go to the next page on the website, to get the next 100 rows and scrape them
    next_soup = BeautifulSoup(driver.page_source, 'html.parser')
    next_soup = next_soup.find('li', {'class': 'paginate_button next'})

    for _ in range(2):
        driver.find_element_by_link_text('Next').click()
        soup = BeautifulSoup(driver.page_source, 'html.parser')
        soup = soup.find('table', {'id': 'datatables-684412'})
        table_rows = soup.find_all('tr')
        list_of_vals = []
        for row in table_rows[1:]:
            entry = row.find_all('td')
            row_list = [value.text for value in entry]
            list_of_vals.append(row_list)
        df_next = pd.DataFrame(list_of_vals, columns=cols)
        df_empl_rank = df_empl_rank.append(df_next, ignore_index=True)

    df_empl_rank.to_csv(f'df_empl_rank.csv')
    return df_empl_rank

def tableau_city_corrections(df):
    ''' this function contains city corrections to be recognised in Tableau
        takes in a dataframe, adjusts the cities of the universities below and returns the dataframe'''

    corrections_for_tableau = {'Gabriele d‘Annunzio University':'Chieti',
 'University of Alberta': 'Edmonton',
 'University of Calgary': 'Calgary',
 'University of Lethbridge': 'Lethbridge',
 'University of Massachusetts': 'Boston',
 'Jawaharlal Nehru Technological University Anantapur (JNTUA)': 'Anantapur',
 'Sri Venkateswara University': 'Tirupati',
 'University of Science and Technology of China': 'Hefei',
 'University of Oviedo': 'Oviedo',
 'CEU Universities': 'Madrid',
 'Benha University': 'Benha',
 'Technical University of Berlin': 'Berlin',
 'Indian Institute of Technology Patna': 'Dayalpur Daulatpur',
 'Virginia Polytechnic Institute and State University': 'Blacksburg',
 'Griffith University': 'Brisbane',
 'University of British Columbia': 'Vancouver',
 'Simon Fraser University': 'Burnaby',
 'University of Victoria': 'Victoria',
 'University of Northern British Columbia (UNBC)': 'Prince George',
 'The University of Tokyo': 'Tokyo',
 'University of Las Palmas de Gran Canaria': 'Las Palmas de Gran Canaria',
 'Lincoln University': 'Lincoln',
 'University of Burgos': 'Burgos',
 'Charles Darwin University': 'Darwin',
 'University of Cergy-Pontoise': 'Cergy',
 'University of Insubria': 'Como',
 'Macau University of Science and Technology': 'Taipa',
 'Jagiellonian University':'Kraków',
 'AGH University of Science and Technology':'Kraków',
 'Cracow University of Technology': 'Kraków',
 'University of Hull': 'Kingston Upon Hull',
 'Central South University': 'Changsha',
 'Hunan University': 'Changsha',
 'University of South China': 'Hengyang',
 'Xiangtan University': 'Xiangtan',
 'Jamia Millia Islamia': 'New Delhi',
 'Nanjing University': 'Nanjing',
 'Soochow University': 'Suzhou',
 'Southeast University': 'Nanjing',
 'Jiangsu Normal University': 'Xuzhou',
 'Nanjing Agricultural University': 'Nanjing',
 'Nanjing University of Information Science and Technology': 'Nanjing',
 'Nanjing Medical University': 'Nanjing',
 'Nanjing Tech University': 'Nanjing',
 'Xi‘an Jiaotong-Liverpool University': 'Suzhou',
 'Jiangsu University': 'Zhenjiang',
 'Nanjing Normal University': 'Nanjing',
 'Shanghai University': 'Shanghai',
 'Yangzhou University': 'Yangzhou',
 'China Pharmaceutical University': 'Nanjing',
 'Nanjing University of Aeronautics and Astronautics': 'Nanjing',
 'Vietnam National University, Hanoi': 'Hanoi',
 'University of Toronto': 'Toronto',
 'McMaster University': 'Hamilton',
 'University of Ottawa': 'Ottawa', 'University of Waterloo': 'Waterloo',
 'Western University': 'London',
 'Queen’s University': 'Kingston',
 'York University': 'Toronto',
 'Carleton University': 'Ottawa',
 'Lakehead University': 'Orillia',
 'University of Guelph': 'Guelph',
 'Ryerson University': 'Toronto',
 'University of Windsor': 'Windsor' ,
 'Georgetown University':'Washington D.C',
 'George Washington University': 'Washington D.C',
 'American University':'Washington D.C',
 'Howard University': 'Washington D.C',
 'Istanbul Technical University':'Istanbul',
 'Normandy University': 'Caen',
 'Memorial University of Newfoundland': "St. John's",
 'Fu Jen Catholic University': 'Taipei',
 'National Taipei University': 'Taipei',
 'Tamkang University': 'Taipei',
 'The Open University': 'Milton Keynes'  ,
 'Northumbria University': 'Newcastle',
 'Dalhousie University': 'Halifax',
 'University of Erlangen-Nuremberg': 'Erlangen',
 'Edge Hill University': 'Liverpool',
 'University of Otago': 'Dunedin',
 'University of Duisburg-Essen': 'Essen',
 'University of La Laguna':'San Cristóbal de La Laguna',
 'National Institute of Technology, Tiruchirappalli':'Tiruchchirappalli',
 'University of Twente':'Enschede',
 'Kanazawa Medical University':'Ishikawa',
 'Ulster University':'Coleraine'   , 
 'Federal University of Rio Grande do Sul':'Porto Alegre',
 'Federal University of Pelotas':'Pelotas',
 'Pontifical Catholic University of Rio Grande do Sul (PUCRS)':'Porto Alegre',
 'Federal University of Santa Catarina':'Florianópolis',
 'University of Saskatchewan':'Saskatoon',
 'University of Regina':'Regina',
 'Universiti Putra Malaysia': 'Kuala Lumpur',
 'Universiti Tenaga Nasional (UNITEN)': 'Kuala Lumpur',
 'Universiti Teknologi MARA': 'Kuala Lumpur'  ,
 'Universiti Kebangsaan Malaysia': 'Kuala Lumpur'  ,
 'Xi’an Jiaotong University':"Xi'an Shi",
 'Northwestern Polytechnical University':"Xi'an Shi",
 'NorthWest A&F University':'Xianyang',
 'Xidian University':"Xi'an Shi",
 'Northwest University':"Xi'an Shi",
 'Shandong University':'Jinan'  ,
 'Ocean University of China':'Qingdao' ,  
 'Southwestern University of Finance and Economics':'Chengdu',   
 'Southwest Jiaotong University':'Chengdu' ,   
 'Tezpur University':'Tezpur'  , 
 'University of Strathclyde':'Glasgow'  ,  
 'SRM Institute of Science and Technology':'Chengalpattu',
 'Anglia Ruskin University ARU':'Cambridge',
 'University of Essex':'Colchester',
 'Swinburne University of Technology' : 'Melbourne',
 'Yanshan University':'Qinhuangdao',
 'Harbin Institute of Technology':'Harbin',
 'University of Hohenheim':'Stuttgart',
 'Wuhan University':'Wuhan',
 'Huazhong University of Science and Technology':'Wuhan',
 'Huazhong Agricultural University':'Wuhan',
 'China University of Geosciences, Wuhan': 'Wuhan',
 'Wuhan University of Technology':'Wuhan',
 'Jianghan University':'Wuhan',
 'Universiti Teknologi Malaysia':'Johor Bahru',
 'Edith Cowan University':'Perth',
 'Kafrelsheikh University':'Kafr el-Cheik',
 'Universiti Utara Malaysia':'Changlun',
 'UNSW Sydney': 'Sydney',
 'University of Kent': 'Canterbury',
 'Dalian University of Technology': 'Dalian',
 'Northeastern University':'Shenyang',
 'Technical University of Denmark':'Kongens Lyngby',
 'Manipal Academy of Higher Education':'Udupi',
 'University of Manitoba':'Winnipeg',
 'Federal University of Maranhão (UFMA)':'São Luís',
 'Dokkyo Medical University':'Tochigi',
 'Federal University of Minas Gerais': 'Belo Horizonte',
 'Federal University of Lavras':'Lavras'    ,
 'Pontifical Catholic University of Minas Gerais': 'Belo Horizonte',
 'The University of the West Indies':'Kingston',
 'University of Malta':'Valletta'  , 
 'Murdoch University':'Perth',
 'University of the Ryukyus':'Okinawa',
 'Covenant University':'Lagos',
 'University of Peradeniya':'Kandy',
 'Universiti Sains Malaysia': 'Penang',
 'South Valley University':'Qena',
 'Federal University of Pernambuco':'Recife'}

    for uni in corrections_for_tableau:
        city = corrections_for_tableau[uni]
        df.loc[df['University'] == uni, 'City'] = city

    return df


def main_script():
    '''this function collects the tables from all the functions, merges them and cleans
        returns the full dataframe'''

    print('Starting to construct the university rankings table')
    df_comp_sci = comp_sci_rankings()
    print('Computer science rankings collected')
    df_bus_econ = business_economics_rankings()
    print('Business rankings collected')
    df_world = world_rankings()
    print('World rankings collected')
    print('Collecting national rankings...')
    df_national = national_rankings()

    df_employable = get_employability_rankings()

    # merges all dataframes
    df = df_world.merge(df_comp_sci[['University', 'Country', 'World Computer Science Ranking']], on= ['University', 'Country'], how='left')
    df = df.merge(df_bus_econ[['University', 'Country', 'World Business and Economics Ranking']], on= ['University', 'Country'], how='left')
    df = df.merge(df_national, on= ['University', 'Country'], how='left')
    df = df.merge(df_employable[['University', 'Country', 'World Employability Ranking']], on=['University', 'Country'], how='left')

    #cleaning
    for column in ['World ranking', 'National Ranking', 'World Computer Science Ranking', 'World Business and Economics Ranking']:
        df[column] = df[column].apply(lambda x: str(x).replace('=', '').replace('+',''))
        df[column] = df[column].apply(lambda x: x[:3] if '–' in x else x)
        df[column] = df[column].apply(lambda x: int(x) if x != 'nan' else None)

    countries = list(df.Country.unique())

    # now fill in the missing national rankings based upon the global rankings
    for country in countries:
        temp = df[df['Country'] == country]
        new_list = [1]
        rankings = list(temp['World ranking'])
        for index, rank in enumerate(rankings):
            if index == 0:
                pass
            else:
                if rank != rankings[index-1]:
                    new_list.append(index+1)
                else:
                    new_list.append(new_list[index-1])

        df.loc[df['Country'] == country,'National Ranking'] = new_list

    print('National rankings collected')
    print('Collecting all university cities...')
    df = populate_cities(df)

    # add populations column
    df_populations = get_populations()

    df = df.merge(df_populations, on=['Country'], how='left')

    df = tableau_city_corrections(df)
    df['City'] = df['City'].apply(lambda city: city.strip())
    print('Table complete')
    return df



if __name__ == '__main__':
    main_script()
