from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
import time
import pandas as pd

def get_soup():
    opts = Options()
    opts.add_argument("--headless")

    with webdriver.Chrome(options=opts) as driver:
        driver.get('https://careers.jpmorgan.com/us/en/about-us/locations')
        time.sleep(3)
        soup = BeautifulSoup(driver.page_source)
    return soup

def get_locations_main():
    
    ''' "main" locations correspond to locations where JPM have a significant 
    presence as defined by the website structure of:
    https://careers.jpmorgan.com/us/en/about-us/locations
    minor locations are locations where JPM has a small office presence '''
    
    soup = get_soup()
    countries = [country.text.strip() for country in soup.find_all('p',{'class':'eyebrow'})]
    cities = [city.text.strip() for city in soup.find_all('a',{'class':'link-primary'})]
    df = pd.DataFrame(columns = ['City','Country','is_main'])
    df['City'] = cities
    df['Country'] = countries
    df['is_main'] = True
    return df

def get_locations_minor():

    soup = get_soup()
    columns = soup.find_all('div',{'class':'col-lg-4 col-md-4 col-sm-4 col-12'})
    words = []
    for column in columns:
        str_col = column.find('p').text
        for item in str(str_col).split('\n'):
            words.append(item)
    city_country = [string.split(',') for string in words]
    list_of_locs = []
    for list in city_country:
        location = []
        if len(list) > 1:
            for word in list:
                location.append(word.strip())
        else:
            continue
        list_of_locs.append(location)
    df = pd.DataFrame(data = list_of_locs, columns = ['City','Country'])
    df['is_main'] = False
    return df


def get_all_offices():
    major = get_locations_main()
    minor = get_locations_minor()
    major.append(minor).to_csv('all_offices.csv')
    return major.append(minor)

get_all_offices()
