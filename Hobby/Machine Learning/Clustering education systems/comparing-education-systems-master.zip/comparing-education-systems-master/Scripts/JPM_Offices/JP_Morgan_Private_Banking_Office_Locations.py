# -*- coding: utf-8 -*-
"""
Created on Fri Oct 16 15:19:02 2020

@author: benny
"""
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
import time
import requests
import json
from bs4 import BeautifulSoup as bs
import datetime as dt
import pandas as pd

# returns a list of urls corresponding to areas where JP Morgan has 
# private banking offices

def get_urls():
    
    opts = Options()
    opts.add_argument("--headless")
    
    with webdriver.Chrome(options=opts) as driver:
        url = r'https://privatebank.jpmorgan.com/gl/en/locations'
        driver.get(url)
        time.sleep(5)
        soup2 = bs(driver.page_source, 'html.parser')
        
    url_list = []

    tag = 'div'
    attributes = {'class':'jpm-wm-contentcard__info'}
    divs = soup2.find_all(tag,attributes)
    for div in divs:
        a = div.find('a') 
        url_list.append('https://privatebank.jpmorgan.com/' + a['href'])

    return url_list


# scrapes the address from a given url (returns a dataframe)

def get_address(url):
    opts = Options()
    opts.add_argument("--headless")
    with webdriver.Chrome(options=opts) as driver:
        driver.get(url)
        time.sleep(5)
        soup = bs(driver.page_source, 'html.parser')
        
    tag = 'a'
    attributes = {'class':'jpm-wm-interactive-office-detail-hero__office-address-link'}
    address_block = soup.find_all(tag, attributes)

    address_lines = [span.find_all('span') for span in address_block]

    df = pd.DataFrame(columns = ['City','Address'])
    
    tag2 = 'h1'
    attributes2 = {'class': 'jpm-wm-interactive-office-detail-hero__office-location'}
    table_soup2 = soup.find(tag2, attributes2)
    city = table_soup2.text.strip()

    for location in address_lines:
        address = [line.text.strip() for line in location]
        all_address = ', '.join(address)
        df = df.append({'City':city, 'Address':all_address}, ignore_index=True)

    return df

# appends addresses to a dataframe
    
def get_private_bank():
    df = pd.DataFrame(columns = ['City','Address'])
    urls = get_urls()
    for ix, url in enumerate(urls):
        print(f'trying url {ix} of {len(urls)}: {url}...')
        df = df.append(get_address(url))
    
    pd.to_csv('JPM_private_banking_offices.csv')
    return df

if __name__ == '__main__':
    get_private_bank()
        