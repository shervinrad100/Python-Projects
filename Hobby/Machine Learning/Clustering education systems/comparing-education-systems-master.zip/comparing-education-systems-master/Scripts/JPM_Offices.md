## JPM_Offices

| **Script:** | 
**JP_Morgan_Private_Banking_Office_Locations.py** 
| ----|----| 
| What it does: | Finds the addresses of every JPM Private Banking office. |
| How it works (description): | Iteratively scrapes https://privatebank.jpmorgan.com/gl/en/locations | 
| What it needs (variables – actual + script notation): | self-contained |
| Output (what it returns): | Returns a dataframe containing two columns: City, Address and exports this to a csv file|


| **Script:** | 
**get_JPM_office_locations.py** 
| ----|----| 
| What it does: | Finds the country and city of every JPM office listed on 'https://careers.jpmorgan.com/us/en/about-us/locations'. |
| How it works (description): | Iteratively scrapes 'https://careers.jpmorgan.com/us/en/about-us/locations' | 
| What it needs (variables – actual + script notation): | self-contained |
| Output (what it returns): | Returns a dataframe containing two columns: City, Country and exports this to a csv file |

## Use-case for scripts:

For visualisation in Tableau in conjunction with university locations.

