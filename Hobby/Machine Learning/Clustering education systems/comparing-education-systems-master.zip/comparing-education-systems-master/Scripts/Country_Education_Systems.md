# Country_Education_Systems  

| **Script:** |  
**country_education_ranking.py** |  
| ----|----|  
| What it does | Returns a CSV file of the metrics that indicates the quality of an education system for every country along with their clustered rank. | 
 | How it works | - Loads multiple .csv files into DataFrames<br> - Uses UMAP to reduce the number of dimensions<br> - Performs KMeans clustering to group these countries into clusters of similar metric sizes<br> - Countries with nulls (not included in KMeans) are then assigned to clusters using Euclidean distance from cluster's average<br> - Ranks these clusters based on Euclidean distance from the origin<br> - Cleans final DataFrame and exports to csv file |  
| What it needs | Self-contained: <br> - Run: `pip install -r [requirements.txt](requirements.txt)` <br> - No other pre-requisites are needed. <br> *To run the script: type `python run_country_education_ranking.py`* | 
 | Output | Returns DataFrame containing 8 columns including country, rank and the education system metrics and exports this to a csv file | 

## DataFrame column names:
* `country` : Name of country
* `country_code` : Three-character uniquely identifying country code
* `rank` : Rank of the cluster that country belongs to
* `gdp_per_capita` : GDP divided by population ($)
* `govt_exp_total` : Percentage of government expenditure spent on education (%)
* `govt_exp_ter_edu` : Percentage of government expenditure on education spent on tertiary education (%)
* `govt_exp_per_student` : Government expenditure on education as a percentage of GDP per capita (%)
* `avg_class_size` : Average number of students per class
* `enrollment_rate` : Percentage of eligible population that goes to school (%)

 ## Use-case for script:
 For visualisation in Tableau alongside the university data