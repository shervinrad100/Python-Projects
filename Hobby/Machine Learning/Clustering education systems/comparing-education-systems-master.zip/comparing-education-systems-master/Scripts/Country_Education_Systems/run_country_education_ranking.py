import country_education_ranking as cer


cer.create_final_output()
