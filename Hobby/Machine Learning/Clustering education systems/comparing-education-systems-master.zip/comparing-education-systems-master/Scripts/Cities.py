# -*- coding: utf-8 -*-
"""
Created on Mon Oct 19 11:45:35 2020

@author: benny
"""

import requests
from bs4 import BeautifulSoup as bs
import pandas as pd

def get_cities():
    
    ''' This function scrapes the cities of the world and 
    can be used to populate the city-level granularity of
    global universities'''
    
    url = r'http://ontheworldmap.com/all/cities/'
    r = requests.get(url)
    soup = bs(r.text, 'html.parser')
    tag = 'div'
    attributes = {'class':'clr'}

    table_soup = soup.find(tag, attributes)
    cities = table_soup.find_all('a')

    cities_clean = []

    for item in cities:
        item = item.text
        cities_clean.append(item)

    # city names start from the 28th element in clean_cities
    del cities_clean[0:27]
    return(cities_clean)


if __name__ == '__main__':
    get_cities()